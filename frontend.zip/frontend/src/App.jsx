import React, { useState, useEffect } from 'react';
import FilesScanned from './components/FilesScanned';
import ThreatsDetected from './components/ThreatsDetected';
import LogFiles from './components/LogFiles';
import MyResponsivePie from './components/Pie';
import ProtectionTips from './components/ProtectionTips';
import Scan from './components/Scan';
import { BounceLoader } from 'react-spinners'; // Importing the loader

function App() {
  const [loading, setLoading] = useState(true); // Loading state for showing loader
  const pieData = [
    { id: 'ransomware', label: 'Ransomware', value: 345, color: 'hsl(0, 70%, 50%)' },
    { id: 'malware', label: 'Malware', value: 512, color: 'hsl(120, 70%, 50%)' },
    { id: 'bruteforce', label: 'Brute Force', value: 238, color: 'hsl(227, 70%, 50%)' },
    { id: 'no-attack', label: 'No Attack', value: 200, color: 'hsl(54, 70%, 50%)' },
  ];

  // Simulate data loading for 3 seconds
  useEffect(() => {
    setTimeout(() => {
      setLoading(false); // After 3 seconds, set loading to false
    }, 1000);
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-white p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">VIGILX Dashboard</h1>
        {/* Scan Button */}
        <div className="pl-20">
          <Scan />
        </div>
      </div>

      {/* Show loader when loading is true */}
      {loading ? (
        <div className="flex justify-center items-center h-[60vh]">
          <BounceLoader color="#00ff00" size={60} />
        </div>
      ) : (
        <div className="grid grid-rows-[0.5fr_0.25fr_auto] grid-cols-3 gap-6">
          {/* Files Scanned */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border-none">
            <FilesScanned />
          </div>

          {/* Threats Detected */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border-none">
            <ThreatsDetected />
          </div>

          {/* Pie Chart: Spanning two rows */}
          <div className="row-span-2 bg-white dark:bg-gray-800 rounded-lg p-4 h-full border-none">
            <MyResponsivePie data={pieData} />
          </div>

          {/* Log Files: Spanning two columns */}
          <div className="col-span-2 bg-white dark:bg-gray-800 rounded-lg p-6 border-none">
            <LogFiles />
          </div>

          {/* Protection Tips */}
          <div className="col-span-1 bg-white dark:bg-gray-800 rounded-lg p-6 border-none">
            <ProtectionTips />
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
