import React from 'react';

function Logo() {
  return (
    <div className="flex items-center bg-blue-600 p-4">
      {/* Logo Text */}
      <h1 className="text-3xl font-extrabold text-white tracking-wide">
        VIGIL<span className="text-yellow-400">X</span>
      </h1>
    </div>
  );
}

export default Logo;
