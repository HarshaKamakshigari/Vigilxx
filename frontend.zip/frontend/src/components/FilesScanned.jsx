import React from 'react';

function FilesScanned() {
  const scannedCount = 120; // Static number of files scanned

  return (
    <div className="bg-white dark:bg-gray-800  p-6">
      <h2 className="text-lg font-semibold text-gray-800 dark:text-white font-roboto">Files Scanned</h2>
      <p className="text-2xl font-bold text-gray-900 dark:text-white font-roboto">{scannedCount}</p>
    </div>
  );
}

export default FilesScanned;
