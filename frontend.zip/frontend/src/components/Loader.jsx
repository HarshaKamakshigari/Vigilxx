import React from 'react';
import { BounceLoader } from 'react-spinners';

const Loader = () => {
  return (
    <div className="flex justify-center items-center h-full">
      <BounceLoader color="#00ff00" size={60} /> {/* Customize size if needed */}
    </div>
  );
};

export default Loader;
