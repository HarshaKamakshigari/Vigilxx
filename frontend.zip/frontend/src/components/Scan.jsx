import React, { useState } from 'react';

const Scan = () => {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleScanClick = async () => {
    setLoading(true);
    setMessage('');

    try {
      const response = await fetch('http://127.0.0.1:5000/api/scan'); // Update with your Flask backend URL
      const data = await response.json();

      if (data.status === 'success') {
        setMessage('Scan started successfully!');
      } else {
        setMessage('Scan failed: ' + data.message);
      }
    } catch (error) {
      setMessage('Error: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <button
        onClick={handleScanClick}
        className="fixed top-4 right-4 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none"
        disabled={loading}
      >
        {loading ? 'Scanning...' : 'Scan'}
      </button>
      {message && (
        <p className="fixed top-16 right-4 text-white bg-green-500 p-2 rounded-lg">
          {message}
        </p>
      )}
    </div>
  );
};

export default Scan;
