import React from 'react';

function ThreatsDetected() {
  const threatCount = 5; // Static number of threats detected

  return (
    <div className="bg-white dark:bg-gray-800  p-6">
      <h2 className="text-lg font-semibold text-gray-800 dark:text-white font-roboto">Threats Detected</h2>
      <p className="text-2xl font-bold text-red-500 dark:text-red-400 font-roboto">{threatCount}</p>
    </div>
  );
}

export default ThreatsDetected;
