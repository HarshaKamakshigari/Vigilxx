import React, { useState, useEffect } from 'react';

const tips = [
  "Use strong, unique passwords for all your accounts.",
  "Enable two-factor authentication wherever possible.",
  "Keep your software and devices updated with the latest patches.",
  "Avoid clicking on suspicious links or attachments in emails.",
  "Use antivirus and anti-malware software to protect your systems.",
  "Regularly back up important data to a secure location.",
  "Limit the amount of personal information you share online.",
  "Be cautious when using public Wi-Fi; consider using a VPN.",
  "Ensure firewalls are enabled on all devices.",
  "Educate yourself and your team about phishing scams and social engineering."
];

function ProtectionTips() {
  const [currentTipIndex, setCurrentTipIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTipIndex((prevIndex) => (prevIndex + 1) % tips.length);
    }, 10000); // Update every 30 seconds
    return () => clearInterval(interval); // Clean up the interval on component unmount
  }, []);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-6 text-center">
      <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Cybersecurity Tip</h2>
      <p className="mt-4 text-gray-600 dark:text-gray-300">{tips[currentTipIndex]}</p>
    </div>
  );
}

export default ProtectionTips;
