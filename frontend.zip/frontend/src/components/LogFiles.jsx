import React from 'react';

function LogFiles() {
  const logs = [
    "File abc.exe scanned successfully.",
    "Threat detected in file xyz.docx.",
    "No issues found in file test.pdf.",
    "File malware.exe quarantined.",
    "Scan completed at 10:30 AM.",
  ]; // Static log data

  return (
    <div className="bg-white dark:bg-gray-800  p-6">
      <h2 className="text-lg font-semibold text-gray-800 dark:text-white font-roboto">Log Files</h2>
      <ul className="mt-4 text-sm text-gray-600 dark:text-gray-300 font-roboto">
        {logs.map((log, index) => (
          <li key={index} className="mb-2">
            {log}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default LogFiles;
